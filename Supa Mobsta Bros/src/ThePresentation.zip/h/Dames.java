/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
 

import java.awt.image.BufferedImage;

/**
 *
 * @author mark
 */
public class Dames extends Enemy
{

	@Override
	public BufferedImage setFrame(int frame)
	{
		throw new UnsupportedOperationException("Not supported yet.");
	}
}
