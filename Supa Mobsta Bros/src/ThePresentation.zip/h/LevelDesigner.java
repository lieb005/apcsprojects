/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
 

import javax.swing.JApplet;

/**
 *
 * @author mark
 */
public class LevelDesigner extends JApplet
{

	public static void main(String[] args)
	{
	}
}
