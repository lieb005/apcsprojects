/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package supa.mobsta.goodguys;

import java.awt.image.BufferedImage;

/**
 *
 * @author mark
 */
public class AlCapone extends GoodGuy
{

	@Override
	public BufferedImage setFrame (int frame)
	{
		throw new UnsupportedOperationException ("Not supported yet.");
	}
}
