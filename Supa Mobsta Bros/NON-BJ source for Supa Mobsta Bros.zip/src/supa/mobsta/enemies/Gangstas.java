/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package supa.mobsta.enemies;

import java.awt.image.BufferedImage;

/**
 *
 * @author mark
 */
public class Gangstas extends Enemy
{

	@Override
	public BufferedImage setFrame (int frame)
	{
		throw new UnsupportedOperationException ("Not supported yet.");
	}
}
